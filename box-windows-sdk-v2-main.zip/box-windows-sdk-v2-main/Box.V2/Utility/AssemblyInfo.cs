namespace Box.V2.Utility
{
    internal class AssemblyInfo
    {
        public const string AssemblyTitle = "Box.V2";
        public const string AssemblyProduct = "Box.V2";

        public const string NuGetVersion = "5.1.0";
        public const string AssemblyVersion = "1.0.0.0";
        public const string AssemblyFileVersion = "1.0.0.0";
    }
}
