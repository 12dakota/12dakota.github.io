namespace Box.V2.Plugins.Managers
{
    public interface IBoxMetadataManager : IResourcePlugin
    {

    }
}
