namespace Box.V2
{
    public interface IResourcePlugin
    {

    }
}
