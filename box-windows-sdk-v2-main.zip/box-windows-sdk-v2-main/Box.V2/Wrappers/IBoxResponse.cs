namespace Box.V2.BoxWrappers
{
    internal interface IBoxResponse
    {
    }
}
